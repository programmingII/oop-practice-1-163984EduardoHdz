/*
  @EduardO Hdz
 Hora de inicio: 22:32
 Hora que se termino: 22:32
 */

public class Programa9Ncientific {
  
    public static void main(String[] args) {

        double i = ((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5)) ;
        System.out. print("El resultado es: "+i);

    }

  }