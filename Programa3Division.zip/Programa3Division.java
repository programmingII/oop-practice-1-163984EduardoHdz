/*
  @EduardO Hdz
 Hora de inicio: 20:08
 Hora que se termino: 20:12
 */
public class Programa3Division {
    public static void main(String[] args) {
        // TODO code application logic here
      	float N1=50,N2=5, resultado = 0;
      	resultado = N1 / N2;
        System.out.println("La division de 50 / 5 es igual a " +resultado);
    }
    
}