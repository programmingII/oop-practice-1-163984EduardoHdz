/*
  @EduardO Hdz
 Hora de inicio: 19:41
 Hora que se termino: 19:42
 */
public class Programa2Suma {
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("La suma de 50+90 es ");
        System.out.println(50+90);
    }
    
}

  