/*
  @EduardO Hdz
 Hora de inicio: 22:23
 Hora que se termino: 22:29
 */

public class Programa8imprimirjava {
  
    public static void main(String[] args) {

          
      System.out.println("   j   aa  v      v  aa");
      System.out.println("   j  aaaa  v    v  aaaa");
      System.out.println("j  j a    a  v  v  a    a");
      System.out.println(" jj a      a  vv  a      a");

    }

  }