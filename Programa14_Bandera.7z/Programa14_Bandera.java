/*
  @EduardO Hdz
 Dia: 07/02/19
 Hora de inicio: 12:36
 Hora que se termino: 12:41
 */

public class Programa14_Bandera {
    public static void main(String[] args) {
        // TODO code application logic here
	
	System.out.println("* * * * * * =================================="); //imprime simbolos
	System.out.println(" * * * * *  =================================="); //imprime simbolos
	System.out.println("* * * * * * =================================="); //imprime simbolos
	System.out.println(" * * * * *  =================================="); //imprime simbolos
	System.out.println("* * * * * * =================================="); //imprime simbolos
	System.out.println(" * * * * *  =================================="); //imprime simbolos
	System.out.println("* * * * * * =================================="); //imprime simbolos
	System.out.println(" * * * * *  =================================="); //imprime simbolos
	System.out.println("* * * * * * =================================="); //imprime simbolos
	System.out.println("=============================================="); //imprime simbolos
	System.out.println("=============================================="); //imprime simbolos
	System.out.println("=============================================="); //imprime simbolos
	System.out.println("=============================================="); //imprime simbolos
	System.out.println("=============================================="); //imprime simbolos
	System.out.println("=============================================="); //imprime simbolos
    }
    
}