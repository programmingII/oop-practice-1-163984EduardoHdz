/*
  @EduardO Hdz
 Dia: 07/02/19
 Hora de inicio: 13:06
 Hora que se termino: 13:08
 */

public class Programa16_face {
    public static void main(String[] args) {
        System.out.println(" +\"\"\"\"\"+ ");   //se imprime simbolos
	System.out.println("[| o o |] ");  //se imprime simbolos
	System.out.println(" |  ^  | ");   //se imprime simbolos
	System.out.println(" | '-' | ");   //se imprime simbolos
	System.out.println(" +-----+ ");   //se imprime simbolos
    }
    
}