/*
  @EduardO Hdz
 Hora de inicio: 21:35
 Hora que se termino: 21:45
 */
import java.util.Scanner;

public class Programa5_capturaymulti {
  
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
      
        System.out.print("Introduce el 1er numero: ");
  	    int num1 = in.nextInt();
   
 	    System.out.print("Introduce el 2do numero: ");
  	    int num2 = in.nextInt();
   
 	    System.out.println(num1 + " x " + num2 + " = " + num1 * num2);
      
    }
    
}