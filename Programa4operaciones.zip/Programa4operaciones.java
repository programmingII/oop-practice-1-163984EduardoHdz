/*
  @EduardO Hdz
 Hora de inicio: 21:26
 Hora que se termino: 21:32
 */
public class Programa4operaciones {
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("a. "+(-5 + 8 * 6));
        System.out.println("b. "+((55+9) % 9));
        System.out.println("c. "+(20 + ((-3*5) / 8)));
        System.out.println("d. "+(5 + 15 / 3 * 2 - 8 % 3 ));
    }
    
}